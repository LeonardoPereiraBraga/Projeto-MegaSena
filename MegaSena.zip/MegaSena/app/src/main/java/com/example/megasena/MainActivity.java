package com.example.megasena;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    // Declarando os componentes da interface
    private TextView num1, num2, num3, num4, num5, num6;
    private Button botaoSortear, botaoLimpar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // 1. Vinculando as variáveis aos IDs do arquivo XML
        num1 = findViewById(R.id.Num1);
        num2 = findViewById(R.id.Num2);
        num3 = findViewById(R.id.Num3);
        num4 = findViewById(R.id.Num4);
        num5 = findViewById(R.id.Num5);
        num6 = findViewById(R.id.Num6);


        botaoSortear = findViewById(R.id.BtnSortear);
        botaoLimpar = findViewById(R.id.BtnLimpar);

        // 2. Configurando a ação de clique do botão "Sorteio"
        botaoSortear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sortearNumeros();
            }
        });

        // 3. Configurando a ação de clique do botão "Limpar"
        botaoLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                limparNumeros();
            }
        });
    }

    // Método responsável por gerar e exibir os números
    private void sortearNumeros() {
        List<Integer> numerosSorteados = new ArrayList<>();
        Random random = new Random();

        // O laço continua até termos 6 números armazenados
        while (numerosSorteados.size() < 6) {

            int numero = random.nextInt(60) + 1;

            // Verifica se o número já existe na lista
            if (!numerosSorteados.contains(numero)) {
                numerosSorteados.add(numero);
            }
        }

        // Ordena os números do menor para o maior
        Collections.sort(numerosSorteados);

        // Deixando os numeros 01...09
        num1.setText(String.format("%02d", numerosSorteados.get(0)));
        num2.setText(String.format("%02d", numerosSorteados.get(1)));
        num3.setText(String.format("%02d", numerosSorteados.get(2)));
        num4.setText(String.format("%02d", numerosSorteados.get(3)));
        num5.setText(String.format("%02d", numerosSorteados.get(4)));
        num6.setText(String.format("%02d", numerosSorteados.get(5)));
    }

    // Resetando os textos para --
    private void limparNumeros() {
        num1.setText("--");
        num2.setText("--");
        num3.setText("--");
        num4.setText("--");
        num5.setText("--");
        num6.setText("--");
    }
}